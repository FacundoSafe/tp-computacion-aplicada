#!/bin/bash

if [[ "$1" == "-help" ]]; then
  echo "Uso: backup_full.sh <origen> <destino>"
  echo "Ejemplo: backup_full.sh /var/log /backup_dir"
  exit 0
fi

if [[ $# -ne 2 ]]; then
  echo "Error: se requieren exactamente 2 argumentos."
  echo "Usá -help para más información."
  exit 1
fi

ORIGEN=$1
DESTINO=$2
FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")

if [[ ! -d "$ORIGEN" ]]; then
  echo "Error: origen $ORIGEN no existe o no es un directorio."
  exit 1
fi

df "$DESTINO" > /dev/null 2>&1 || { echo "Error: destino $DESTINO no disponible."; exit 1; }

ARCHIVO="${DESTINO}/${NOMBRE}_bkp_${FECHA}.tar.gz"
tar -czf "$ARCHIVO" "$ORIGEN"

if [[ $? -eq 0 ]]; then
  echo "Backup exitoso: $ARCHIVO"
else
  echo "Error al crear el backup."
  exit 1
fi

