history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostnamectl set-hostname TPServer
vi /etc/hosts
head /etc/hosts
hostnamectl
vi /etc/apt/sources.list
apt update
vi /etc/apt/sources.list
apt update
vi /etc/apt/sources.list
apt update
apt upgrade -y
vi /etc/apt/sources.list
head /etc/apt/sources.list
apt update && apt full-upgrade -y
apt autoremove -y
reboot
cat /etc/os-release 
apt install openssh-server -y
ls /root/.ssh/
systemctl status ssh
ssh-keygen -t rsa -b 4096
cat /root/.ssh/id_rsa.pub >> /root/.ssh/authorized_keys
chmod 600 /root/.ssh/authorized_keys 
vi /etc/ssh/sshd_config
systemctl restart ssh
systemctl enable ssh
apt update
ls -la
apt install apache2 -y
apt install apache2 php libapache2-mod-php -y
php -v
ls
tar -xzf Material_Adicional_TPVMCA.tar.gz .
tar -xzf Material_Adicional_TPVMCA.tar.gz
ls
cd Material_Adicional_TPVMCA/
ls
cat clave_privada.txt 
ls
cp clave_privada.txt /root/.ssh/id_rsa
cp clave_publica.pub /root/.ssh/id_rsa.pub
cd ..
chmod 600 /root/.ssh/id_rsa
chmod 600 /root/.ssh/id_rsa.pub 
cat /root/.ssh/id_rsa.pub >> /root/.ssh/authorized_keys 
cat /root/.ssh/authorized_keys 
cat Material_Adicional_TPVMCA/clave_publica.pub 
vi /root/.ssh/authorized_keys 
rm /root/.ssh/authorized_keys 
cat /root/.ssh/id_rsa.pub >> /root/.ssh/authorized_keys 
cat /root/.ssh/authorized_keys 
chmod 600 /root/.ssh/authorized_keys 
systemctl restart ssh
systemctl status ssh
systemctl status apache2
cp Material_Adicional_TPVMCA/index.php /var/www/html/
cp Material_Adicional_TPVMCA/logo.png /var/www/html/
systemctl restart apache2
systemctl status apache2
apt update
apt install mariadb-server -y
mysql -u root < /root/Material_Adicional_TPVMCA/db.sql 
mysql -u rrot -e "SHOW DATABASES;"
mysql -u root -e "SHOW DATABASES;"
ip a
vi /etc/network/interfaces
systemctl restart networking
systemctl status networking
ping google.com
ip a
ip a
shutdown -now
man shutdown
shutdown
lsblk
echo "UUID=$(blkid -s UUID -o value /dev/sdc1)  /www_dir     ext4  defaults  0  2" >> /etc/fstab
echo "UUID=$(blkid -s UUID -o value /dev/sdc2)  /backup_dir  ext4  defaults  0  2" >> /etc/fstab
lsblk
cat /etc/fstabYou said: portateles compartido bidireccional no me está dejando pegar dentro de la vm y pegar
cat /etc/fstab
mount -a
systemctl daemon-reload
mount -a
lsblk
cat /proc/partitions > /opt/particion
cat /opt/particion
ls /www_dir/
mkdir -p /opt/scripts
vi /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh -help
sudo /opt/scripts/backup_full.sh -help
/opt/scripts/backup_full.sh -help
cat /opt/scripts/backup_full.sh
vi /opt/scripts/backup_full.sh
chmod +x /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh -help
/opt/scripts/backup_full.sh /var/log /backup_dir
ls /backup_dir/
rm /backup_dir/log_bkp_20260602.tar.gz 
crontab -e
vi /etc/ssh/sshd_config
exit
